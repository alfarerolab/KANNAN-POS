"use client";
import { BarModule } from "@/components/bar/BarModule";

export default function BarPage() {
  return <BarModule modo="bar" />;
}
