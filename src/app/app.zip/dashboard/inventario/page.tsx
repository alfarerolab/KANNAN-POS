"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Package,
  Search,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Plus,
  Minus,
  BarChart3,
  RefreshCw,
  Edit3,
  Loader2,
  ShoppingCart,
  AlertCircle,
  CheckCircle,
  Clock
} from "lucide-react";
import Link from "next/link";
import { formatCurrency } from "@/lib/utils";

interface ProductoInventario {
  id: string;
  nombre: string;
  categoria: string;
  stock: number;
  stockMinimo: number;
  precio: number;
  ultimaActualizacion: string;
  estado: "normal" | "bajo" | "agotado";
  sku?: string;
  codigoBarras?: string;
  valorInventario: number;
}

interface EstadisticasInventario {
  totalProductos: number;
  productosConStockBajo: number;
  productosAgotados: number;
  valorTotalInventario: number;
  productosNormales: number;
}

interface InventarioResponse {
  inventario: ProductoInventario[];
  estadisticas: EstadisticasInventario;
}

export default function InventarioPage() {
  const [productos, setProductos] = useState<ProductoInventario[]>([]);
  const [estadisticas, setEstadisticas] = useState<EstadisticasInventario>({
    totalProductos: 0,
    productosConStockBajo: 0,
    productosAgotados: 0,
    valorTotalInventario: 0,
    productosNormales: 0
  });
  const [filtro, setFiltro] = useState("");
  const [loading, setLoading] = useState(true);
  const [actualizando, setActualizando] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [productoSeleccionado, setProductoSeleccionado] = useState<ProductoInventario | null>(null);
  const [cantidadAjuste, setCantidadAjuste] = useState<number>(1);
  const [tipoAjuste, setTipoAjuste] = useState<'entrada' | 'salida'>('entrada');
  const { toast } = useToast();

  const cargarInventario = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/inventario', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache'
        },
        cache: 'no-store'
      });
      
      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        throw new Error('El servidor devolvió una respuesta inválida (no JSON)');
      }

      const data: InventarioResponse = await response.json();
      
      if (data.inventario && Array.isArray(data.inventario)) {
        setProductos(data.inventario);
        if (data.estadisticas) {
          setEstadisticas(data.estadisticas);
        }
      } else {
        throw new Error('Formato de datos incorrecto');
      }
      
    } catch (error) {
      console.error("Error al cargar inventario:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "No se pudo cargar el inventario",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const abrirDialogoAjuste = (producto: ProductoInventario, tipo: 'entrada' | 'salida') => {
    setProductoSeleccionado(producto);
    setTipoAjuste(tipo);
    setCantidadAjuste(1);
    setDialogOpen(true);
  };

  const ajustarStock = async () => {
    if (!productoSeleccionado || cantidadAjuste <= 0) return;

    try {
      setActualizando(productoSeleccionado.id);
      
      const response = await fetch('/api/inventario/movimientos', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          productoId: productoSeleccionado.id,
          tipo: tipoAjuste.toUpperCase(),
          cantidad: cantidadAjuste,
          motivo: `Ajuste manual desde inventario - ${tipoAjuste}`
        }),
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        throw new Error('Error en el servidor - respuesta inválida');
      }

      const result = await response.json();

      toast({
        title: "Stock actualizado",
        description: `${tipoAjuste === 'entrada' ? 'Agregadas' : 'Removidas'} ${cantidadAjuste} unidades de ${productoSeleccionado.nombre}`,
      });
      
      setDialogOpen(false);
      await cargarInventario();
      
    } catch (error) {
      console.error("Error al ajustar stock:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "No se pudo actualizar el stock",
        variant: "destructive",
      });
    } finally {
      setActualizando(null);
    }
  };

  useEffect(() => {
    cargarInventario();
  }, []);

  const productosFiltrados = productos.filter(producto =>
    producto.nombre.toLowerCase().includes(filtro.toLowerCase()) ||
    producto.categoria.toLowerCase().includes(filtro.toLowerCase()) ||
    (producto.sku && producto.sku.toLowerCase().includes(filtro.toLowerCase()))
  );

  const getEstadoBadge = (estado: string, stock: number) => {
    switch (estado) {
      case "normal":
        return (
          <Badge variant="outline" className="bg-emerald-500/10 text-green-700 dark:text-green-400 border-emerald-500/30 hover:bg-emerald-500/15">
            <CheckCircle className="w-3 h-3 mr-1" />
            Normal
          </Badge>
        );
      case "bajo":
        return (
          <Badge variant="outline" className="bg-amber-500/10 text-yellow-700 dark:text-yellow-400 border-amber-500/30 hover:bg-amber-500/15">
            <Clock className="w-3 h-3 mr-1" />
            Stock Bajo
          </Badge>
        );
      case "agotado":
        return (
          <Badge variant="outline" className="bg-destructive/10 text-red-700 dark:text-red-400 border-destructive/30 hover:bg-destructive/15">
            <AlertCircle className="w-3 h-3 mr-1" />
            Agotado
          </Badge>
        );
      default:
        return <Badge variant="outline">{estado}</Badge>;
    }
  };

  const formatearFecha = (fecha: string) => {
    return new Date(fecha).toLocaleDateString('es-ES', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  const formatearHora = (fecha: string) => {
    return new Date(fecha).toLocaleTimeString('es-ES', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStockColor = (stock: number, stockMinimo: number) => {
    if (stock === 0) return "text-red-600 dark:text-red-400 font-bold";
    if (stock <= stockMinimo) return "text-yellow-600 dark:text-yellow-400 font-semibold";
    return "text-green-600 dark:text-green-400 font-medium";
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="flex flex-col items-center gap-3">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <p className="text-muted-foreground">Cargando inventario...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-8 max-w-7xl mx-auto">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 px-1">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Inventario</h1>
          <p className="text-base text-muted-foreground">
            Gestiona tu inventario en tiempo real
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            onClick={cargarInventario}
            disabled={loading}
            className="flex items-center gap-2 px-4 h-11 shadow-sm transition-all duration-200"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            Actualizar
          </Button>
          <Link href="/dashboard/inventario/movimientos">
            <Button variant="outline" className="flex items-center gap-2 px-4 h-11 shadow-sm transition-all duration-200">
              <BarChart3 className="h-4 w-4" />
              Movimientos
            </Button>
          </Link>
          <Link href="/dashboard/productos/nuevo">
            <Button className="flex items-center gap-2 px-6 h-11 shadow-sm bg-primary hover:bg-primary/90 transition-all duration-200">
              <Plus className="h-4 w-4" />
              Nuevo Producto
            </Button>
          </Link>
        </div>
      </div>

      {/* Estadísticas */}
      <div className="grid gap-6 md:grid-cols-4">
        <Card className="border border-border shadow-sm bg-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-card-foreground">Total Productos</CardTitle>
            <div className="w-8 h-8 rounded-lg bg-blue-500/15 flex items-center justify-center">
              <Package className="h-4 w-4 text-blue-600 dark:text-blue-400" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-card-foreground">{estadisticas.totalProductos}</div>
            <p className="text-xs text-muted-foreground">En el inventario</p>
          </CardContent>
        </Card>

        <Card className="border border-border shadow-sm bg-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-card-foreground">Stock Bajo</CardTitle>
            <div className="w-8 h-8 rounded-lg bg-amber-500/15 flex items-center justify-center">
              <AlertTriangle className="h-4 w-4 text-yellow-600 dark:text-yellow-400" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-card-foreground">{estadisticas.productosConStockBajo}</div>
            <p className="text-xs text-muted-foreground">Requieren reposición</p>
          </CardContent>
        </Card>

        <Card className="border border-border shadow-sm bg-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-card-foreground">Agotados</CardTitle>
            <div className="w-8 h-8 rounded-lg bg-destructive/15 flex items-center justify-center">
              <TrendingDown className="h-4 w-4 text-red-600 dark:text-red-400" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-card-foreground">{estadisticas.productosAgotados}</div>
            <p className="text-xs text-muted-foreground">Sin stock disponible</p>
          </CardContent>
        </Card>

        <Card className="border border-border shadow-sm bg-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-card-foreground">Valor Total</CardTitle>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/15 flex items-center justify-center">
              <TrendingUp className="h-4 w-4 text-green-600 dark:text-green-400" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-card-foreground">{formatCurrency(estadisticas.valorTotalInventario)}</div>
            <p className="text-xs text-muted-foreground">Valor del inventario</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Card */}
      <Card className="border border-border shadow-sm bg-card">
        <CardHeader className="pb-6 border-b border-border/50">
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
            <div className="space-y-1">
              <CardTitle className="text-xl font-semibold text-card-foreground">
                Gestión de Inventario
              </CardTitle>
              <CardDescription className="text-base text-muted-foreground">
                {productosFiltrados.length === 0 && filtro
                  ? "No se encontraron resultados para tu búsqueda"
                  : `${productosFiltrados.length} ${productosFiltrados.length === 1 ? 'producto' : 'productos'} ${filtro ? 'encontrado(s)' : 'en total'}`
                }
              </CardDescription>
            </div>
            
            <div className="flex w-full sm:w-auto max-w-sm">
              <div className="relative w-full">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por nombre, categoría o SKU..."
                  className="pl-10 h-11 bg-background border-input focus:border-ring transition-colors duration-200"
                  value={filtro}
                  onChange={(e) => setFiltro(e.target.value)}
                />
              </div>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="p-0">
          <div className="overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="border-b border-border/50 bg-muted/30 hover:bg-muted/40">
                  <TableHead className="font-semibold text-foreground py-4 px-6">Producto</TableHead>
                  <TableHead className="font-semibold text-foreground py-4 px-6">Categoría</TableHead>
                  <TableHead className="font-semibold text-foreground py-4 px-6">Stock</TableHead>
                  <TableHead className="font-semibold text-foreground py-4 px-6">Precio</TableHead>
                  <TableHead className="font-semibold text-foreground py-4 px-6">Estado</TableHead>
                  <TableHead className="font-semibold text-foreground py-4 px-6">Última Actualización</TableHead>
                  <TableHead className="text-right font-semibold text-foreground py-4 px-6">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {productosFiltrados.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center h-32 px-6">
                      <div className="flex flex-col items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center">
                          <Package className="h-6 w-6 text-muted-foreground" />
                        </div>
                        <div className="space-y-1">
                          <p className="font-medium text-foreground">
                            {filtro
                              ? "No se encontraron productos"
                              : "No hay productos en el inventario"}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {filtro
                              ? "Intenta con otros términos de búsqueda"
                              : "Crea tu primer producto para comenzar"}
                          </p>
                        </div>
                        {!filtro && (
                          <Link href="/dashboard/productos/nuevo">
                            <Button variant="outline" className="mt-2">
                              <Plus className="h-4 w-4 mr-2" />
                              Crear primer producto
                            </Button>
                          </Link>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  productosFiltrados.map((producto) => (
                    <TableRow key={producto.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors duration-150">
                      <TableCell className="py-4 px-6">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-sm">
                            <span className="text-primary-foreground text-sm font-semibold">
                              {producto.nombre.charAt(0).toUpperCase()}
                            </span>
                          </div>
                          <div className="flex flex-col">
                            <span className="font-semibold text-foreground">{producto.nombre}</span>
                            <div className="flex items-center gap-2 mt-1">
                              {producto.sku && (
                                <span className="px-2 py-1 bg-blue-500/15 text-blue-800 dark:text-blue-300 rounded text-xs font-medium">
                                  SKU: {producto.sku}
                                </span>
                              )}
                              {producto.codigoBarras && (
                                <span className="px-2 py-1 bg-muted text-foreground/80 rounded text-xs font-medium">
                                  CB: {producto.codigoBarras}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="py-4 px-6">
                        <span className="px-3 py-1 text-slate-950 rounded-full text-sm font-medium">
                          {producto.categoria}
                        </span>
                      </TableCell>
                      <TableCell className="py-4 px-6">
                        <div className="flex flex-col gap-1">
                          <span className={`text-lg font-bold ${getStockColor(producto.stock, producto.stockMinimo)}`}>
                            {producto.stock}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            Mín: {producto.stockMinimo}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="py-4 px-6">
                        <span className="font-semibold text-foreground">{formatCurrency(producto.precio)}</span>
                      </TableCell>
                      <TableCell className="py-4 px-6">
                        {getEstadoBadge(producto.estado, producto.stock)}
                      </TableCell>
                      <TableCell className="py-4 px-6">
                        <div className="flex flex-col gap-1">
                          <span className="text-sm font-medium text-foreground">
                            {formatearFecha(producto.ultimaActualizacion)}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {formatearHora(producto.ultimaActualizacion)}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right py-4 px-6">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => abrirDialogoAjuste(producto, 'salida')}
                            disabled={producto.stock === 0 || actualizando === producto.id}
                            className="h-9 w-9 hover:bg-destructive/10 hover:border-destructive/30 hover:text-red-700 dark:text-red-400 transition-all duration-200"
                            title="Reducir stock"
                          >
                            {actualizando === producto.id ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <Minus className="h-4 w-4" />
                            )}
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => abrirDialogoAjuste(producto, 'entrada')}
                            disabled={actualizando === producto.id}
                            className="h-9 w-9 hover:bg-emerald-500/10 hover:border-emerald-500/30 hover:text-green-700 dark:text-green-400 transition-all duration-200"
                            title="Aumentar stock"
                          >
                            {actualizando === producto.id ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <Plus className="h-4 w-4" />
                            )}
                          </Button>
                          <Link href={`/dashboard/productos/${producto.id}`}>
                            <Button 
                              variant="outline" 
                              size="icon" 
                              className="h-9 w-9 hover:bg-blue-500/10 hover:border-blue-500/30 hover:text-blue-700 dark:text-blue-400 transition-all duration-200"
                              title="Editar producto"
                            >
                              <Edit3 className="h-4 w-4" />
                            </Button>
                          </Link>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Dialog para ajuste de stock */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader className="text-left">
            <DialogTitle className="flex items-center gap-3 text-xl">
              {tipoAjuste === 'entrada' ? (
                <div className="w-10 h-10 rounded-full bg-emerald-500/15 flex items-center justify-center">
                  <Plus className="h-5 w-5 text-green-600 dark:text-green-400" />
                </div>
              ) : (
                <div className="w-10 h-10 rounded-full bg-destructive/15 flex items-center justify-center">
                  <Minus className="h-5 w-5 text-red-600 dark:text-red-400" />
                </div>
              )}
              {tipoAjuste === 'entrada' ? 'Agregar Stock' : 'Remover Stock'}
            </DialogTitle>
            <DialogDescription className="text-base leading-relaxed pt-2">
              {productoSeleccionado && (
                <>
                  Producto: <span className="font-semibold text-foreground">{productoSeleccionado.nombre}</span>
                  <br />
                  Stock actual: <span className="font-semibold text-lg text-foreground">{productoSeleccionado.stock}</span>
                </>
              )}
            </DialogDescription>
          </DialogHeader>

          <div className="py-4">
            <label className="text-sm font-medium mb-2 block">Cantidad:</label>
            <Input
              type="number"
              min="1"
              value={cantidadAjuste}
              onChange={(e) => setCantidadAjuste(Math.max(1, parseInt(e.target.value) || 1))}
              className="text-center text-lg font-semibold h-12"
              placeholder="Ingresa la cantidad"
            />
            
            {productoSeleccionado && (
              <div className="mt-4 p-3 bg-muted rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Nuevo stock:</p>
                <p className="text-xl font-bold text-foreground">
                  {tipoAjuste === 'entrada' 
                    ? productoSeleccionado.stock + cantidadAjuste
                    : Math.max(0, productoSeleccionado.stock - cantidadAjuste)
                  }
                </p>
              </div>
            )}
          </div>

          <DialogFooter className="gap-3 pt-6">
            <Button 
              variant="outline" 
              onClick={() => setDialogOpen(false)}
              disabled={!!actualizando}
              className="flex-1 sm:flex-none"
            >
              Cancelar
            </Button>
            <Button 
              onClick={ajustarStock}
              disabled={!!actualizando || cantidadAjuste <= 0}
              className={`flex-1 sm:flex-none ${tipoAjuste === 'entrada' 
                ? 'bg-green-600 hover:bg-green-700' 
                : 'bg-red-600 hover:bg-red-700'
              }`}
            >
              {actualizando ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Actualizando...
                </div>
              ) : (
                `${tipoAjuste === 'entrada' ? 'Agregar' : 'Remover'} ${cantidadAjuste}`
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}