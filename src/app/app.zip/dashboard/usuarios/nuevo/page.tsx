"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Save, X, UserPlus, Mail, Phone, Shield, Eye, EyeOff } from "lucide-react";
import Link from "next/link";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { useAuth } from "@/hooks/use-auth";

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { esAdminOGerente } from "@/lib/auth/auth";

// Esquema de validación para el formulario
const usuarioFormSchema = z.object({
  nombre: z
    .string()
    .min(2, { message: "El nombre debe tener al menos 2 caracteres" })
    .max(100, { message: "El nombre no puede tener más de 100 caracteres" }),
  email: z
    .string()
    .email({ message: "Debe ser un correo electrónico válido" }),
  telefono: z
    .string()
    .max(15, { message: "El teléfono no puede tener más de 15 caracteres" })
    .optional()
    .or(z.literal("")),
  contrasena: z
    .string()
    .min(8, { message: "La contraseña debe tener al menos 8 caracteres" }),
  confirmarContrasena: z
    .string()
    .min(8, { message: "La contraseña debe tener al menos 8 caracteres" }),
  rol: z.enum(["ADMINISTRADOR", "GERENTE", "EMPLEADO"]),
  imagen: z
    .string()
    .optional()
    .or(z.literal("")),
})
.refine((data) => data.contrasena === data.confirmarContrasena, {
  message: "Las contraseñas no coinciden",
  path: ["confirmarContrasena"],
});

type UsuarioFormValues = z.infer<typeof usuarioFormSchema>;

export default function NuevoUsuarioPage() {
  const { toast } = useToast();
  const router = useRouter();
  const { session } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [mostrarContrasena, setMostrarContrasena] = useState(false);
  const [mostrarConfirmar, setMostrarConfirmar] = useState(false);

  // Verificar que el usuario tiene permisos para gestionar usuarios
  useEffect(() => {
    if (session && !esAdminOGerente(session.user.role)) {
      toast({
        title: "Acceso denegado",
        description: "No tienes permisos para crear usuarios",
        variant: "destructive",
      });
      router.push("/dashboard/usuarios");
    }
  }, [session, router, toast]);

  // Definir valores por defecto para el formulario
  const defaultValues: Partial<UsuarioFormValues> = {
    nombre: "",
    email: "",
    telefono: "",
    contrasena: "",
    confirmarContrasena: "",
    rol: "EMPLEADO",
    imagen: "",
  };

  const form = useForm<UsuarioFormValues>({
    resolver: zodResolver(usuarioFormSchema),
    defaultValues,
  });

  async function onSubmit(data: UsuarioFormValues) {
    setIsSubmitting(true);

    try {
      // Excluir confirmarContrasena del payload
      const { confirmarContrasena, ...formData } = data;

      const response = await fetch("/api/usuarios", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Error al crear el usuario");
      }

      toast({
        title: "¡Usuario creado exitosamente!",
        description: `${data.nombre} ha sido agregado al sistema`,
      });

      // Redireccionar al listado de usuarios
      router.push("/dashboard/usuarios");
      router.refresh();
    } catch (error) {
      console.error("Error:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Error al crear el usuario",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  // Definir qué roles puede crear el usuario actual
  const availableRoles = session?.user.role === "ADMINISTRADOR"
    ? ["ADMINISTRADOR", "GERENTE", "EMPLEADO"]
    : ["EMPLEADO"];

  return (
    <div className="flex flex-col gap-8 max-w-4xl mx-auto">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center gap-4">
        <div className="flex items-center gap-3">
          <Link href="/dashboard/usuarios">
            <Button 
              variant="outline" 
              size="icon" 
              className="h-10 w-10 hover:bg-muted transition-colors duration-200"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div className="space-y-1">
            <h1 className="text-3xl font-bold tracking-tight text-foreground">Nuevo Usuario</h1>
            <p className="text-muted-foreground">
              Crea una nueva cuenta de usuario para el sistema
            </p>
          </div>
        </div>
      </div>

      {/* Main Form Card */}
      <Card className="border border-border shadow-sm bg-card">
        <CardHeader className="pb-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-sm">
              <UserPlus className="h-6 w-6 text-primary-foreground" />
            </div>
            <div className="flex-1">
              <CardTitle className="text-xl font-semibold text-card-foreground">
                Información del Usuario
              </CardTitle>
              <CardDescription className="text-base text-muted-foreground mt-1">
                Completa todos los datos necesarios para crear la cuenta de usuario
              </CardDescription>
            </div>
          </div>
        </CardHeader>

        <Separator className="mx-6" />

        <CardContent className="pt-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <div className="grid grid-cols-1 gap-6">
                {/* Información Personal */}
                <div className="space-y-4">
                  <h3 className="text-lg font-medium text-foreground">Información Personal</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="nombre"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base font-medium text-foreground flex items-center gap-2">
                            <UserPlus className="h-4 w-4" />
                            Nombre Completo *
                          </FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Ej: Juan Pérez González"
                              className="h-11 bg-background border-input focus:border-ring transition-colors duration-200"
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription className="text-sm text-muted-foreground">
                            Nombre completo del usuario tal como aparecerá en el sistema
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base font-medium text-foreground flex items-center gap-2">
                            <Mail className="h-4 w-4" />
                            Correo Electrónico *
                          </FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="usuario@empresa.com"
                              type="email"
                              className="h-11 bg-background border-input focus:border-ring transition-colors duration-200"
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription className="text-sm text-muted-foreground">
                            Email para iniciar sesión y recibir notificaciones
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="telefono"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-base font-medium text-foreground flex items-center gap-2">
                          <Phone className="h-4 w-4" />
                          Teléfono
                        </FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Ej: +57 300 123 4567"
                            className="h-11 bg-background border-input focus:border-ring transition-colors duration-200"
                            {...field} 
                          />
                        </FormControl>
                        <FormDescription className="text-sm text-muted-foreground">
                          Número de contacto del usuario (opcional)
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Separator />

                {/* Rol y Permisos */}
                <div className="space-y-4">
                  <h3 className="text-lg font-medium text-foreground">Rol y Permisos</h3>
                  <FormField
                    control={form.control}
                    name="rol"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-base font-medium text-foreground flex items-center gap-2">
                          <Shield className="h-4 w-4" />
                          Rol del Usuario *
                        </FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger className="h-11 bg-background border-input focus:border-ring transition-colors duration-200">
                              <SelectValue placeholder="Selecciona un rol" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {availableRoles.includes("ADMINISTRADOR") && (
                              <SelectItem value="ADMINISTRADOR" className="flex items-center gap-2">
                                <div className="flex items-center gap-2">
                                  <Shield className="h-4 w-4" />
                                  Administrador
                                </div>
                              </SelectItem>
                            )}
                            {availableRoles.includes("GERENTE") && (
                              <SelectItem value="GERENTE">
                                <div className="flex items-center gap-2">
                                  <Shield className="h-4 w-4" />
                                  Gerente
                                </div>
                              </SelectItem>
                            )}
                            <SelectItem value="EMPLEADO">
                              <div className="flex items-center gap-2">
                                <UserPlus className="h-4 w-4" />
                                Empleado
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                        <div className="text-sm text-muted-foreground mt-2 space-y-1">
                          <div className="flex items-center gap-2 text-xs">
                            <div className="w-2 h-2 rounded-full bg-red-500"></div>
                            <span><strong>Administrador:</strong> Acceso completo al sistema</span>
                          </div>
                          <div className="flex items-center gap-2 text-xs">
                            <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
                            <span><strong>Gerente:</strong> Gestión de productos, ventas y reportes</span>
                          </div>
                          <div className="flex items-center gap-2 text-xs">
                            <div className="w-2 h-2 rounded-full bg-green-500"></div>
                            <span><strong>Empleado:</strong> Solo realizar ventas</span>
                          </div>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Separator />

                {/* Seguridad */}
                <div className="space-y-4">
                  <h3 className="text-lg font-medium text-foreground">Seguridad</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="contrasena"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base font-medium text-foreground">
                            Contraseña *
                          </FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Input
                                type={mostrarContrasena ? "text" : "password"}
                                placeholder="••••••••"
                                className="h-11 bg-background border-input focus:border-ring transition-colors duration-200 pr-10"
                                {...field}
                              />
                              <button
                                type="button"
                                onClick={() => setMostrarContrasena(!mostrarContrasena)}
                                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                              >
                                {mostrarContrasena ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                              </button>
                            </div>
                          </FormControl>
                          <FormDescription className="text-sm text-muted-foreground">
                            Mínimo 8 caracteres para mayor seguridad
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="confirmarContrasena"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base font-medium text-foreground">
                            Confirmar Contraseña *
                          </FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Input
                                type={mostrarConfirmar ? "text" : "password"}
                                placeholder="••••••••"
                                className="h-11 bg-background border-input focus:border-ring transition-colors duration-200 pr-10"
                                {...field}
                              />
                              <button
                                type="button"
                                onClick={() => setMostrarConfirmar(!mostrarConfirmar)}
                                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                              >
                                {mostrarConfirmar ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                              </button>
                            </div>
                          </FormControl>
                          <FormDescription className="text-sm text-muted-foreground">
                            Repite la contraseña para confirmar
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="flex flex-col-reverse sm:flex-row justify-end gap-3 pt-2">
                <Link href="/dashboard/usuarios">
                  <Button 
                    variant="outline" 
                    type="button"
                    className="w-full sm:w-auto h-11 px-8 border-input hover:bg-muted transition-all duration-200"
                  >
                    <X className="h-4 w-4 mr-2" />
                    Cancelar
                  </Button>
                </Link>
                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full sm:w-auto h-11 px-8 bg-primary hover:bg-primary/90 transition-all duration-200 shadow-sm"
                >
                  {isSubmitting ? (
                    <div className="flex items-center gap-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      Creando...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Save className="h-4 w-4" />
                      Crear Usuario
                    </div>
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* Help Section */}
      <Card className="bg-emerald-500/10/50 border-emerald-500/30/50">
        <CardContent className="pt-6">
          <div className="flex gap-3">
            <div className="w-2 h-2 rounded-full bg-green-500 mt-2 flex-shrink-0"></div>
            <div className="space-y-1">
              <p className="text-sm font-medium text-green-900">
                Consejos de Seguridad
              </p>
              <p className="text-sm text-green-800 dark:text-green-300">
                Usa contraseñas seguras con al menos 8 caracteres. El usuario podrá cambiar su contraseña 
                después de iniciar sesión por primera vez. Asigna roles según las responsabilidades del usuario.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}